Signature PNG utilisée dans l'app
