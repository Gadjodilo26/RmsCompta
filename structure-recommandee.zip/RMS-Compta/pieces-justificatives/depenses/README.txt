Pièces liées aux dépenses
