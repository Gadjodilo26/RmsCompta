Copies de devis/factures envoyées
