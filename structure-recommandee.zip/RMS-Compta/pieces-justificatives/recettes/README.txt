Pièces liées aux recettes
