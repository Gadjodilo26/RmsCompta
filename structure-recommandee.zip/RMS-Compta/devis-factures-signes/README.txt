Versions signées des devis/factures
